console.log('Hello world from client-side JS!')
